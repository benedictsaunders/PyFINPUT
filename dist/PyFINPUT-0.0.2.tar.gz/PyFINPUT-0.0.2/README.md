# PyFINPUT
### Python File INPUT
At times, repeatedly using 20 command line arguments is frustrating.

Why not use an input file?

